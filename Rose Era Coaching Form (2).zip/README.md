# Rose Era Coaching — BLOOM with Quadia

The digital home of the **Rose Era** 6-week coaching experience: the client-facing
web pages, the long-form letters, and the email templates that hold the journey together.

Live site: https://entering-the-rose-era.netlify.app

---

## What's in here

```
rose-era-coaching/
│
├── index.html                  ← Rose Era welcome + weekly practices (the public site root)
├── onboarding.html             ← "Life After Survival" client intake (Netlify form)
├── thank-you.html              ← Confirmation page shown after the intake is submitted
│
├── letters/                    ← Private long-form essays (unlisted, noindex)
│   └── article-week-2-breathe.html
│
├── emails/                     ← Source HTML to paste into Zoho. NOT website pages.
│   ├── welcome.html            ← Week 1 welcome email
│   └── coaching-reminder.html  ← Google Meet reminder (send 24h before each call)
│
├── reference/                  ← Internal planning. Not sent, not linked publicly.
│   └── sunday-letters.html     ← The full six-week Sunday email arc (copy source)
│
├── README.md                   ← This file
└── .gitignore
```

**Deployed to the website:** `index.html`, `onboarding.html`, `thank-you.html`, and `letters/`.
**Source only (used by hand):** everything in `emails/` and `reference/`. They live in the
repo so they are backed up and versioned, but you copy from them — you don't link to them.

---

## How each piece is used

| Asset | Where it lives | How it's used |
|---|---|---|
| `index.html` | Website root `/` | The Rose Era welcome + habit picker. Saves to the client's own phone. |
| `onboarding.html` | Website `/onboarding` | Intake form. Submits to Netlify; turn on form notifications to get emailed. |
| `thank-you.html` | Website `/thank-you` | The page the form lands on after submit. |
| `letters/…` | Website `/letters/…` | Deep weekly essays. Unguessable filename + noindex = private link. Paste the link into the Sunday email. |
| `emails/welcome.html` | Zoho | Paste into Zoho's HTML view to send the Week 1 welcome. |
| `emails/coaching-reminder.html` | Zoho | Paste into Zoho; schedule to send 24h before each Thursday call. |
| `reference/sunday-letters.html` | Your reference | The mapped six-week arc. Copy each week's letter from here into Zoho. |

---

## ⚠️ Placeholders to replace before sending

Search each email file for these and swap in real values (in **all** the spots shown):

- `emails/welcome.html`
  - `REPLACE_WITH_FORM_URL` → the Rose Era link
  - `hello@bloomwithquadia.com` → your real Zoho address (mailto link **and** visible text)
- `emails/coaching-reminder.html`
  - `REPLACE_WITH_MEET_LINK` → the Google Meet URL (button **and** any text)
  - `DAY, DATE at TIME` → the actual call time
- `thank-you.html`
  - `hello@bloomwithquadia.com` → your real Zoho address

---

## Deploying (Netlify)

This repo is the site. Any push to the main branch republishes automatically once the
repo is connected to Netlify. To update a page, edit the file, commit, and push.

After deploy, confirm:
1. Netlify → Forms → **client-onboarding** is receiving submissions.
2. Netlify → Forms → Settings → **email notifications** are turned on (so intakes reach you).

---

## Where this lives (your library)

- **GitHub** — source of truth and version history. Edit here, push, Netlify deploys.
- **Google Drive** — keep a synced copy of this folder for backup and easy phone access.
- **VS Code** — open this folder to edit any file when you want more room than the browser.

Keep one rule: **GitHub is the master copy.** When in doubt, the version in GitHub wins,
and Drive is the backup.
